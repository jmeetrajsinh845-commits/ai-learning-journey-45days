"""
Day 9 — Cross-Validation Strategies
=====================================
Compares KFold, StratifiedKFold, TimeSeriesSplit, GroupKFold
on the same churn dataset to show how CV strategy choice
affects reported model performance.

Run:  python src/cv_strategies.py
"""

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import (
    KFold,
    StratifiedKFold,
    TimeSeriesSplit,
    GroupKFold,
    cross_val_score,
)
from xgboost import XGBClassifier


# ─────────────────────────────────────────────
# 1. DATASETS
# ─────────────────────────────────────────────

def build_standard_dataset(n: int = 600, seed: int = 42):
    """
    Standard churn dataset — no time order, no groups.
    Same synthetic data used in Days 5-8.
    """
    np.random.seed(seed)
    df = pd.DataFrame({
        "days_inactive":    np.random.randint(0, 180, n),
        "rfm_score":        np.random.uniform(0, 100, n),
        "total_spend":      np.random.uniform(500, 15_000, n),
        "orders":           np.random.randint(1, 50, n),
        "engagement_score": np.random.uniform(0, 10, n),
    })
    df["churn_risk"] = (
        (df["days_inactive"] > 60) | (df["rfm_score"] < 25)
    ).astype(int)
    X = df.drop("churn_risk", axis=1)
    y = df["churn_risk"]
    return X, y


def build_timeseries_dataset(n_days: int = 365, seed: int = 42):
    """
    Time-ordered churn dataset.
    Rows are sorted by date — must NOT be shuffled.
    Simulates: one churn snapshot per customer per day.
    """
    np.random.seed(seed)
    dates = pd.date_range("2023-01-01", periods=n_days, freq="D")
    df = pd.DataFrame({
        "date":             dates,
        "days_inactive":    np.random.randint(0, 180, n_days),
        "rfm_score":        np.random.uniform(0, 100, n_days),
        "total_spend":      np.random.uniform(500, 15_000, n_days),
        "orders":           np.random.randint(1, 50, n_days),
        "engagement_score": np.random.uniform(0, 10, n_days),
    })
    # Add time trend: churn increases in Q4 (seasonal drift)
    df["churn_risk"] = (
        (df["days_inactive"] > 60) |
        (df["rfm_score"] < 25) |
        (df["date"].dt.month.isin([10, 11, 12]) & (df["rfm_score"] < 40))
    ).astype(int)
    df = df.sort_values("date").reset_index(drop=True)
    X = df.drop(["churn_risk", "date"], axis=1)
    y = df["churn_risk"]
    return X, y, df["date"]


def build_grouped_dataset(n_customers: int = 60,
                          snapshots_per: int = 10,
                          seed: int = 42):
    """
    Grouped churn dataset.
    Each customer has multiple rows (monthly snapshots).
    GroupKFold ensures no customer appears in both train and test.
    """
    np.random.seed(seed)
    n = n_customers * snapshots_per
    customer_ids = np.repeat(np.arange(n_customers), snapshots_per)

    # Customer-level fixed effects (some customers churn-prone by nature)
    customer_churn_bias = np.random.uniform(-20, 20, n_customers)
    row_bias = customer_churn_bias[customer_ids]

    df = pd.DataFrame({
        "customer_id":      customer_ids,
        "days_inactive":    np.random.randint(0, 180, n),
        "rfm_score":        np.random.uniform(0, 100, n) + row_bias * 0.3,
        "total_spend":      np.random.uniform(500, 15_000, n),
        "orders":           np.random.randint(1, 50, n),
        "engagement_score": np.random.uniform(0, 10, n),
    })
    df["churn_risk"] = (
        (df["days_inactive"] > 60) | (df["rfm_score"] < 25)
    ).astype(int)

    X = df.drop(["churn_risk", "customer_id"], axis=1)
    y = df["churn_risk"]
    groups = df["customer_id"].values
    return X, y, groups


# ─────────────────────────────────────────────
# 2. MODEL BUILDER
# ─────────────────────────────────────────────

def make_model(y) -> XGBClassifier:
    """XGBoost with imbalance handling."""
    spw = (y == 0).sum() / (y == 1).sum()
    return XGBClassifier(
        n_estimators=200,
        learning_rate=0.1,
        max_depth=4,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=spw,
        eval_metric="logloss",
        random_state=42,
        verbosity=0,
    )


# ─────────────────────────────────────────────
# 3. STRATEGY COMPARISONS
# ─────────────────────────────────────────────

def compare_basic_strategies():
    """
    KFold vs StratifiedKFold on standard (i.i.d.) data.
    Expected result: StratifiedKFold is more stable (lower std).
    """
    print("\n" + "=" * 55)
    print("EXPERIMENT 1 — KFold vs StratifiedKFold")
    print("Data: standard i.i.d. churn, 10% minority class")
    print("=" * 55)

    X, y = build_standard_dataset()
    model = make_model(y)

    strategies = {
        "KFold (no stratify)":  KFold(n_splits=5, shuffle=True, random_state=42),
        "StratifiedKFold":      StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
    }

    print(f"\n  {'Strategy':<24} {'F1 mean':>8} {'F1 std':>8}  Verdict")
    print("  " + "-" * 58)
    for name, cv in strategies.items():
        s = cross_val_score(model, X, y, cv=cv, scoring="f1")
        verdict = "✓ stable" if s.std() < 0.05 else "⚠ unstable"
        print(f"  {name:<24} {s.mean():>8.4f} {s.std():>8.4f}  {verdict}")

    print("""
  Interpretation:
  StratifiedKFold keeps 90/10 class ratio in every fold.
  KFold may create folds with 95/5 or 85/15 by chance.
  Higher std = noisier evaluation = less reliable model selection.
    """)


def compare_timeseries_strategies():
    """
    StratifiedKFold (WRONG) vs TimeSeriesSplit (CORRECT) on time data.
    Expected: StratifiedKFold is optimistic — inflated F1.
    """
    print("\n" + "=" * 55)
    print("EXPERIMENT 2 — TimeSeriesSplit vs StratifiedKFold")
    print("Data: time-ordered, seasonal churn drift in Q4")
    print("=" * 55)

    X, y, dates = build_timeseries_dataset(n_days=365)
    model = make_model(y)

    print(f"\n  Churn rate overall:     {y.mean()*100:.1f}%")
    print(f"  Churn rate Jan-Sep:     "
          f"{y[dates.dt.month < 10].mean()*100:.1f}%")
    print(f"  Churn rate Oct-Dec:     "
          f"{y[dates.dt.month >= 10].mean()*100:.1f}%")
    print("  → Distribution shifts across time (realistic!)")

    cv_wrong   = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_correct = TimeSeriesSplit(n_splits=5)

    s_wrong   = cross_val_score(model, X, y, cv=cv_wrong,   scoring="f1")
    s_correct = cross_val_score(model, X, y, cv=cv_correct, scoring="f1")

    print(f"\n  {'Strategy':<30} {'F1 mean':>8} {'F1 std':>8}")
    print("  " + "-" * 50)
    print(f"  {'StratifiedKFold (WRONG for time)':<30} "
          f"{s_wrong.mean():>8.4f} {s_wrong.std():>8.4f}  ← optimistic")
    print(f"  {'TimeSeriesSplit (CORRECT)':<30} "
          f"{s_correct.mean():>8.4f} {s_correct.std():>8.4f}  ← honest")

    gap = s_wrong.mean() - s_correct.mean()
    print(f"\n  Gap: {gap:.4f} ({gap*100:.1f} percentage points)")
    print("""
  Why the gap exists:
  StratifiedKFold allows training on Q4 data to predict Q3 rows.
  The model effectively sees the future during training.
  TimeSeriesSplit: train always ends before test begins.
  This gap is exactly the CV-vs-test drop from Day 8's challenge.
    """)

    # Show fold dates
    print("  TimeSeriesSplit fold structure:")
    for fold, (train_idx, test_idx) in enumerate(cv_correct.split(X), 1):
        t0 = dates.iloc[train_idx[0]].date()
        t1 = dates.iloc[train_idx[-1]].date()
        v0 = dates.iloc[test_idx[0]].date()
        v1 = dates.iloc[test_idx[-1]].date()
        print(f"    Fold {fold}: train {t0}→{t1} | test {v0}→{v1}")


def compare_group_strategies():
    """
    StratifiedKFold (leaks) vs GroupKFold (correct) on customer data.
    Expected: StratifiedKFold is optimistic because same customer
              appears in both train and test folds.
    """
    print("\n" + "=" * 55)
    print("EXPERIMENT 3 — GroupKFold vs StratifiedKFold")
    print("Data: 60 customers, 10 snapshots each (600 rows)")
    print("=" * 55)

    X, y, groups = build_grouped_dataset()
    model = make_model(y)

    cv_wrong   = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_correct = GroupKFold(n_splits=5)

    s_wrong   = cross_val_score(model, X, y, cv=cv_wrong,   scoring="f1")
    s_correct = cross_val_score(model, X, y, cv=cv_correct, scoring="f1",
                                groups=groups)

    print(f"\n  {'Strategy':<35} {'F1 mean':>8} {'F1 std':>8}")
    print("  " + "-" * 55)
    print(f"  {'StratifiedKFold (customer leakage)':<35} "
          f"{s_wrong.mean():>8.4f} {s_wrong.std():>8.4f}  ← inflated")
    print(f"  {'GroupKFold (no customer leakage)':<35} "
          f"{s_correct.mean():>8.4f} {s_correct.std():>8.4f}  ← honest")

    gap = s_wrong.mean() - s_correct.mean()
    print(f"\n  Gap: {gap:.4f} ({gap*100:.1f} percentage points)")
    print("""
  Why the gap exists:
  StratifiedKFold: Customer #12's Jan snapshot is in training.
                   Customer #12's Jul snapshot is in test.
                   Model "knows" Customer #12 — easy prediction.

  GroupKFold:      Entire Customer #12 either in train OR test.
                   Test contains only customers never seen in training.
                   Simulates real production: new customer arrives.

  Real-world consequence:
  Model deployed → sees new customers it has never encountered.
  StratifiedKFold CV said 82% → production shows 65%.
  GroupKFold CV said 67% → production shows 65%. (Honest!)
    """)


# ─────────────────────────────────────────────
# 4. DECISION GUIDE
# ─────────────────────────────────────────────

def print_decision_guide():
    print("\n" + "=" * 55)
    print("CV STRATEGY DECISION GUIDE")
    print("=" * 55)
    print("""
  Is your data time-ordered?
    YES → TimeSeriesSplit
          • Sort by date first (critical!)
          • Never shuffle
          • n_splits=5 gives expanding window

    NO  → Do rows share a group identity?
          (same user / patient / store / device)

          YES → GroupKFold
                • Pass groups= to cross_val_score
                • Entire group stays in one fold
                • More honest, usually lower score

          NO  → Classification with imbalanced classes?

                YES → StratifiedKFold  ← your Days 5-8 default
                      shuffle=True, random_state=42

                NO  → KFold
                      (regression, or balanced classification)
    """)


# ─────────────────────────────────────────────
# 5. MAIN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("\nDay 9 — Cross-Validation Strategies")
    print("Churn Prediction: which CV is honest for your data?")

    compare_basic_strategies()
    compare_timeseries_strategies()
    compare_group_strategies()
    print_decision_guide()

    print("=" * 55)
    print("Done. Next: Day 10 — SHAP values (explainable AI)")
    print("=" * 55)
