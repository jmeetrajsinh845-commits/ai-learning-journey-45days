"""
TimeSeriesSplit — Fold-by-fold walkthrough
==========================================
Shows exactly what data each fold trains on and tests on.
Run this to understand WHY order matters for time-series CV.

Run:  python src/timeseries_walkthrough.py
"""

import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.metrics import f1_score
from xgboost import XGBClassifier


def build_dataset(n_days=365, seed=42):
    np.random.seed(seed)
    dates = pd.date_range("2023-01-01", periods=n_days, freq="D")
    df = pd.DataFrame({
        "date":             dates,
        "days_inactive":    np.random.randint(0, 180, n_days),
        "rfm_score":        np.random.uniform(0, 100, n_days),
        "total_spend":      np.random.uniform(500, 15_000, n_days),
        "orders":           np.random.randint(1, 50, n_days),
        "engagement_score": np.random.uniform(0, 10, n_days),
    })
    df["churn_risk"] = (
        (df["days_inactive"] > 60) |
        (df["rfm_score"] < 25) |
        (df["date"].dt.month.isin([10, 11, 12]) & (df["rfm_score"] < 40))
    ).astype(int)
    df = df.sort_values("date").reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = build_dataset()
    X = df.drop(["churn_risk", "date"], axis=1)
    y = df["churn_risk"]
    dates = df["date"]

    spw = (y == 0).sum() / (y == 1).sum()
    model = XGBClassifier(
        n_estimators=200, learning_rate=0.1, max_depth=4,
        scale_pos_weight=spw, eval_metric="logloss",
        random_state=42, verbosity=0
    )

    tscv = TimeSeriesSplit(n_splits=5)

    print("\nTimeSeriesSplit — Fold-by-Fold Detail")
    print("=" * 60)
    print("Rule: test period always comes AFTER training period.")
    print("      Training window expands each fold.\n")

    fold_scores = []

    for fold, (train_idx, test_idx) in enumerate(tscv.split(X), 1):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        train_start = dates.iloc[train_idx[0]].strftime("%b %d")
        train_end   = dates.iloc[train_idx[-1]].strftime("%b %d")
        test_start  = dates.iloc[test_idx[0]].strftime("%b %d")
        test_end    = dates.iloc[test_idx[-1]].strftime("%b %d")

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        f1 = f1_score(y_test, y_pred)
        fold_scores.append(f1)

        churn_train = y_train.mean() * 100
        churn_test  = y_test.mean() * 100

        print(f"Fold {fold}:")
        print(f"  Train: {train_start} → {train_end}  "
              f"({len(train_idx):>3} rows, {churn_train:.1f}% churn)")
        print(f"  Test:  {test_start} → {test_end}   "
              f"({len(test_idx):>3} rows, {churn_test:.1f}% churn)")
        print(f"  F1 on test: {f1:.4f}")
        print()

    print("-" * 40)
    print(f"Mean F1 across folds: {np.mean(fold_scores):.4f}")
    print(f"Std  F1 across folds: {np.std(fold_scores):.4f}")
    print()
    print("Notice:")
    print("  Fold 1 has smallest training set → highest variance")
    print("  Fold 5 has largest  training set → most reliable")
    print("  Churn rate may vary by fold → seasonal drift visible")
    print()
    print("If churn_test >> churn_train in later folds:")
    print("  That is real distribution shift.")
    print("  Your model was trained in low-churn periods")
    print("  and tested in high-churn periods.")
    print("  This is exactly what StratifiedKFold HIDES.")
