# Day 9 — Cross-Validation Strategies

> Part of a 45-day Data Science + ML + AI learning journey.
> Continuing the **Customer Churn Prediction** project from Days 5–8.

---

## The core problem this project solves

Most tutorials teach you one CV strategy and move on.
In production, using the wrong strategy gives you an inflated F1 score that collapses when the model meets real data.

This project shows — with measurable numbers — how each strategy
changes your reported performance, and more importantly, **which one is honest**.

---

## Four strategies, three experiments

### Experiment 1 — KFold vs StratifiedKFold

Data: standard i.i.d. churn (600 rows, 10% minority class)

```
KFold:            F1 = 0.72 ± 0.09   ← high variance, unstable
StratifiedKFold:  F1 = 0.74 ± 0.03   ← lower variance, reliable
```

KFold with imbalanced data creates folds with random class ratios.
One fold might have 4% churn, another 16%. StratifiedKFold fixes this.

---

### Experiment 2 — StratifiedKFold vs TimeSeriesSplit

Data: time-ordered churn, seasonal drift in Q4 (churn rate rises Oct–Dec)

```
StratifiedKFold (wrong):  F1 = 0.81   ← optimistic, future leaked into past
TimeSeriesSplit (correct): F1 = 0.69   ← honest, past always trains future
```

**Why the gap?** StratifiedKFold shuffles rows. A training fold may contain
December data while a test fold contains August data — the model trains on
the future to predict the past. TimeSeriesSplit enforces strict temporal order.

This is the exact mechanism behind the 79% CV → 62% test gap from Day 8.

---

### Experiment 3 — StratifiedKFold vs GroupKFold

Data: 60 customers, 10 monthly snapshots each (600 rows)

```
StratifiedKFold (leaks):  F1 = 0.82   ← inflated, same customer in train + test
GroupKFold (correct):     F1 = 0.67   ← honest, each customer in one fold only
```

**Why the gap?** StratifiedKFold splits rows, not customers.
Customer #12's January snapshot goes to training; their July snapshot goes to test.
The model effectively "memorizes" each customer's behavior pattern.
In production it sees entirely new customers — and fails.

GroupKFold ensures every customer is entirely in training OR test, never both.

---

## Project structure

```
day9-cross-validation/
├── src/
│   ├── cv_strategies.py          # Main: all 3 experiments + decision guide
│   └── timeseries_walkthrough.py # TimeSeriesSplit fold-by-fold breakdown
├── requirements.txt
└── README.md
```

---

## How to run

```bash
pip install -r requirements.txt

# Run all three experiments + decision guide
python src/cv_strategies.py

# See exactly what TimeSeriesSplit does fold by fold
python src/timeseries_walkthrough.py
```

---

## CV strategy decision guide

```
Is your data time-ordered?
  YES → TimeSeriesSplit
        Sort by date first. Never shuffle.

  NO  → Do rows share a group identity?
        (same user / patient / store / device)

        YES → GroupKFold
              Pass groups= to cross_val_score

        NO  → Imbalanced classification?

              YES → StratifiedKFold   ← your standard default
              NO  → KFold
```

---

## Key concepts

**Why CV strategy affects your score**

Your CV strategy simulates how the model will be used in production.
If the simulation is wrong, the score is wrong.

- TimeSeriesSplit simulates: "train on historical data, predict future data"
- GroupKFold simulates: "train on known customers, predict new customers"
- StratifiedKFold simulates: "predict random new rows from the same distribution"

Use the strategy that matches your actual production scenario.

**The `groups=` parameter**

```python
scores = cross_val_score(
    model, X, y,
    cv=GroupKFold(n_splits=5),
    groups=customer_ids,   # required — tells sklearn which rows belong together
    scoring='f1'
)
```

Forgetting `groups=` means GroupKFold splits by row index, not by group.
It silently gives the same (wrong) result as StratifiedKFold.

**Sorting for TimeSeriesSplit**

```python
df = df.sort_values('date').reset_index(drop=True)
# THEN create X and y
# TimeSeriesSplit uses row position, not actual dates
```

If rows are not sorted by date, TimeSeriesSplit splits by position —
which means random rows, not time-ordered rows. Same bug as using KFold.

---

## Common mistakes

| Mistake | Fix |
|---|---|
| `shuffle=True` with TimeSeriesSplit | Never shuffle time-ordered data |
| StratifiedKFold on time-ordered data | Use TimeSeriesSplit |
| GroupKFold without `groups=` | Always pass `groups=` explicitly |
| KFold on imbalanced classification | Use StratifiedKFold |
| Different CV strategies for model comparison | Use identical strategy for all models |
| Forgetting to sort by date before TimeSeriesSplit | `df.sort_values('date')` first |

---

## Connection to Day 8

Day 8's mini challenge asked: "CV F1 = 79%, test F1 = 62% — why?"

One major cause is CV strategy mismatch.
If your data has time structure or group structure, StratifiedKFold
gives an optimistic CV score that doesn't reflect real performance.
This project demonstrates that gap with measurable numbers.

---

## Journey so far

| Day | Topic | Key outcome |
|---|---|---|
| 1 | Problem framing | Defined churn as a business problem |
| 2 | EDA | Found key patterns in data |
| 3 | Statistics | Distributions, hypothesis testing |
| 4 | Feature engineering | Built RFM score, domain features |
| 5 | Logistic Regression | Baseline model, AUC 99.3% |
| 6 | Random Forest | Learned when LR beats RF |
| 7 | XGBoost | SHAP values, scale_pos_weight |
| 8 | Hyperparameter tuning | GridSearchCV + Optuna |
| 9 | Cross-validation | Honest evaluation ← **you are here** |
| 10 | SHAP values in depth | Coming next |

---

## Skills demonstrated

- `KFold`, `StratifiedKFold`, `TimeSeriesSplit`, `GroupKFold`
- `cross_val_score` with `groups=` parameter
- Measuring and explaining the CV-vs-test performance gap
- Seasonal drift detection via fold-level churn rate analysis
- Decision logic for CV strategy selection

---

*Day 9 of 45 | Customer Churn Prediction Series*
